package com.utility;

import jakarta.mail.MessagingException;

public class MailMessage {
	public static void registrationSuccess(String emailId, String name) {
		String recipient = emailId;
		String subject = "Successfully Registered On EBookStore";
		String htmlTextMessage = "" + "<html>" + "<body>"
				+ "<h2 style='color:black;'>EBookStore</h2>" + "" + "Hi " + name + ","
				+ "<br><br>Welcome to the EBookStore.<br>"
				+ "Thank you for choosing us, Hope you will find somethig to read!";
			
		try {
			JavaMailUtil.sendMail(recipient, subject, htmlTextMessage);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void transactionSuccess(String recipientEmail, String name, String transId, double transAmount) {
		String recipient = recipientEmail;
		String subject = "Order Successful";
		String htmlTextMessage = "<html>" + "  <body>" + "    <p>" + "      Hello " + name + ",<br/><br/>"
				+ "      Thank you for choosing us" + "      <br/><br/>"
				+ "      Your order has been placed successfully ."
				+ "      <br/>" + "     Order Details:<br/>" + "      <br/>"
				+ "      <font style=\"color: black;font-weight:bold;\">Order Id:</font>"
				+ "      <font style=\"color:black;font-weight:bold;\">" + transId + "</font><br/>" + "      <br/>"
				+ "      <font style=\"color:balck;font-weight:bold;\">Amount:</font> <font style=\"color:black;font-weight:bold;\">"
				+ transAmount + "</font>" + "      <br/><br/>" + "      Thanks You!<br/><br/>"
				+ "      Come Shop Again! <br/<br/> <font style=\"color:black;font-weight:bold;\"></font>"
				+ "    </p>" + "    " + "  </body>" + "</html>";

		try {
			JavaMailUtil.sendMail(recipient, subject, htmlTextMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	public static void orderShipped(String recipientEmail, String name, String transId, double transAmount) {
		String recipient = recipientEmail;
		String subject = "Hurray!!, Your Order has been Shipped from EBookStore";
		String htmlTextMessage = "<html>" + "  <body>" + "    <p>" + "      Hey " + name + ",<br/><br/>"
				+ "      We are glad that you shop with EBookStore!" + "      <br/><br/>"
				+ "      Your order has been shipped successfully and on the way to be delivered."
				+ "      <font style=\"color:red;font-weight:bold;\">Amount Paid:</font> <font style=\"color:black;font-weight:bold;\">"
				+ transAmount + "</font>" + "      <br/><br/>" + "      Thanks you!<br/><br/>"
				+ "      Come Shop Again! <br/<br/> <font style=\"color:black;font-weight:bold;\"></font>"
				+ "    </p>" + "    " + "  </body>" + "</html>";

		try {
			JavaMailUtil.sendMail(recipient, subject, htmlTextMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	public static void productAvailableNow(String recipientEmail, String name, String prodName, String prodId) {
		String recipient = recipientEmail;
		String subject = "Product " + prodName + " is Now Available right now";
		String htmlTextMessage = "<html>" + "  <body>" + "    <p>" + "      Hey " + name + ",<br/><br/>"
				+ "      Thank you for choosing us" + "      <br/><br/>"
				+ "Accourding to Your search for <font style=\"color:green;font-weight:bold;\">" + prodName
				+ "</font> with " + "product Id <font style=\"color:green;font-weight:bold;\">" + prodId
				+ "</font> is now available!"
				+ "      <br/>" + "      Here is The product detail which is now available to shop:<br/>"
				+ "      <br/>"
				+ "      <font style=\"color:red;font-weight:bold;\">Product Id: </font><font style=\"color:black;font-weight:bold;\">"
				+ prodId + " " + "      </font><br/>" + "      <br/>"
				+ "      <font style=\"color:red;font-weight:bold;\">Product Name: </font> <font style=\"color:black;font-weight:bold;\">"
				+ prodName + "</font>" + "      <br/><br/>" + "      Thanks for shopping with us!<br/><br/>"
				+ "      Come Shop Again! <br/<br/><br/> <font style=\"color:balck;font-weight:bold;\"></font>"
				+ "    </p>" + "    " + "  </body>" + "</html>";

		try {
			JavaMailUtil.sendMail(recipient, subject, htmlTextMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	public static String sendMessage(String toEmailId, String subject, String htmlTextMessage) {
		try {
			JavaMailUtil.sendMail(toEmailId, subject, htmlTextMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
			return "FAILURE";
		}
		return "SUCCESS";
	}
}
