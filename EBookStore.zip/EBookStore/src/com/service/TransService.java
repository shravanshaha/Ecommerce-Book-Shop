package com.service;

public interface TransService {

	public String getUserId(String transId);
}
